textures: https://www.planetminecraft.com/texture_pack/cmr-exterme-realistic-256x-bump-mapping/
wool sound: https://freesound.org/people/akennedybrewer/sounds/389170/
lava sound: https://freesound.org/people/MrVasLuk/sounds/304619/
glass sound: https://freesound.org/people/mgamabile/sounds/440773/